Private Sub Option1_Click() 'D33F30
  loc_00D33F8C: ecx = "DIS"
  loc_00D33F95: var_eax = Call Form2.Variant_process
  loc_00D33FB4: var_eax = Unknown_VTable_Call[eax+00000488h]
  loc_00D33FCB: Me.Enabled = edi
  loc_00D33FFA: GoTo loc_00D34006
  loc_00D34005: Exit Sub
  loc_00D34006: 'Referenced from: 00D33FFA
End Sub