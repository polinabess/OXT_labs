Private Sub Option12_Click() 'D34680
  Dim var_20 As VScrollBar
  loc_00D346CE: var_eax = Unknown_VTable_Call[edx+0000031Ch]
  loc_00D346E8: Me.Width = 0
  loc_00D34714: var_eax = Unknown_VTable_Call[edx+00000320h]
  loc_00D34729: Me.Width = 0
  loc_00D34752: var_eax = Unknown_VTable_Call[eax+00000324h]
  loc_00D34767: Me.Width = NAN
  loc_00D34790: var_eax = Unknown_VTable_Call[edx+00000328h]
  loc_00D347A5: Me.Width = 0
  loc_00D347CE: var_eax = Unknown_VTable_Call[eax+0000032Ch]
  loc_00D347E3: Me.Width = 0
  loc_00D3480C: var_eax = Unknown_VTable_Call[edx+00000330h]
  loc_00D34821: Me.Width = 0
  loc_00D3484A: var_eax = Unknown_VTable_Call[eax+00000334h]
  loc_00D3485F: Me.Width = 0
  loc_00D3489D: VScroll1.Value = 0
  loc_00D348C6: var_eax = Unknown_VTable_Call[eax+00000324h]
  loc_00D348DC: var_20 = VScroll1.Enabled
  loc_00D34923: VScroll1.Max = CInt((5.79330657065194E-315 - var_20))
  loc_00D34961: var_eax = Call Form2.VScroll1_Change
  loc_00D3498A: GoTo loc_00D349A0
  loc_00D3499F: Exit Sub
  loc_00D349A0: 'Referenced from: 00D3498A
  loc_00D349A0: Exit Sub
End Sub