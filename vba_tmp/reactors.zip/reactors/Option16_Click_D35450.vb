Private Sub Option16_Click() 'D35450
  loc_00D354B3: var_eax = Unknown_VTable_Call[ecx+00000074h]
  loc_00D354DD: GoTo loc_00D354E9
  loc_00D354E8: Exit Sub
  loc_00D354E9: 'Referenced from: 00D354DD
End Sub