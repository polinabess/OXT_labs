Private Sub Command3_Click() 'D309E0
  Dim var_1C As Me
  loc_00D30A87: ecx = &HD2A924
  loc_00D30A90: var_eax = Unknown_VTable_Call[edx+00000430h]
  loc_00D30AAA: var_18 = Me.MousePointer
  loc_00D30AE2: ecx = CSng(var_1C)
  loc_00D30B01: var_eax = Unknown_VTable_Call[ecx+0000042Ch]
  loc_00D30B1C: var_18 = Me.MousePointer
  loc_00D30B57: ecx = CSng(var_1C)
  loc_00D30B6A: var_eax = Unknown_VTable_Call[eax+0000043Ch]
  loc_00D30B85: var_18 = Me.MousePointer
  loc_00D30BC3: ecx = CSng(var_1C)
  loc_00D30BD6: var_eax = Unknown_VTable_Call[ecx+00000438h]
  loc_00D30BF1: var_18 = Me.MousePointer
  loc_00D30C16: var_18 = CSng(var_1C)
  loc_00D30C2F: var_eax = Unknown_VTable_Call[eax+00000434h]
  loc_00D30C4A: var_18 = Me.MousePointer
  loc_00D30C88: ecx = CSng(var_1C)
  loc_00D30C9B: var_eax = Unknown_VTable_Call[ecx+0000041Ch]
  loc_00D30CB6: var_18 = Me.MousePointer
  loc_00D30CF4: ecx = CSng(var_1C)
  loc_00D30D07: var_eax = Unknown_VTable_Call[eax+00000418h]
  loc_00D30D22: var_18 = Me.MousePointer
  loc_00D30D60: ecx = CSng(var_1C)
  loc_00D30D73: var_eax = Unknown_VTable_Call[ecx+00000414h]
  loc_00D30D8E: var_18 = Me.MousePointer
  loc_00D30DCC: ecx = CSng(var_1C)
  loc_00D30DDF: var_eax = Unknown_VTable_Call[eax+000003CCh]
  loc_00D30DFA: var_18 = Me.MousePointer
  loc_00D30E38: ecx = CSng(var_1C)
  loc_00D30E4B: var_eax = Unknown_VTable_Call[ecx+000003C8h]
  loc_00D30E66: var_18 = Me.MousePointer
  loc_00D30EA4: ecx = CSng(var_1C)
  loc_00D30EB7: var_eax = Unknown_VTable_Call[eax+000003C4h]
  loc_00D30ED2: var_18 = Me.MousePointer
  loc_00D30F10: ecx = CSng(var_1C)
  loc_00D30F23: var_eax = Unknown_VTable_Call[ecx+000003C0h]
  loc_00D30F3E: var_18 = Me.MousePointer
  loc_00D30F7C: ecx = CSng(var_1C)
  loc_00D30F8F: var_eax = Unknown_VTable_Call[eax+000003BCh]
  loc_00D30FAA: var_18 = Me.MousePointer
  loc_00D30FE8: ecx = CSng(var_1C)
  loc_00D30FFB: var_eax = Unknown_VTable_Call[ecx+000003B8h]
  loc_00D31016: var_18 = Me.MousePointer
  loc_00D31054: ecx = CSng(var_1C)
  loc_00D31067: var_eax = Unknown_VTable_Call[eax+000003B4h]
  loc_00D31082: var_18 = Me.MousePointer
  loc_00D310A7: var_18 = CSng(var_1C)
  loc_00D310C0: var_eax = Unknown_VTable_Call[ecx+000003B0h]
  loc_00D310DB: var_18 = Me.MousePointer
  loc_00D31119: ecx = CSng(var_1C)
  loc_00D3112C: var_eax = Unknown_VTable_Call[eax+000003ACh]
  loc_00D31147: var_18 = Me.MousePointer
  loc_00D31185: ecx = CSng(var_1C)
  loc_00D31198: var_eax = Unknown_VTable_Call[ecx+000003A8h]
  loc_00D311B3: var_18 = Me.MousePointer
  loc_00D311F1: ecx = CSng(var_1C)
  loc_00D31204: var_eax = Unknown_VTable_Call[eax+000003D0h]
  loc_00D3121F: var_18 = Me.MousePointer
  loc_00D3125D: ecx = CSng(var_1C)
  loc_00D31270: var_eax = Unknown_VTable_Call[ecx+000003A4h]
  loc_00D3128B: var_18 = Me.MousePointer
  loc_00D312B0: var_18 = CSng(var_1C)
  loc_00D312C9: var_eax = Unknown_VTable_Call[eax+000003A0h]
  loc_00D312E4: var_18 = Me.MousePointer
  loc_00D31322: ecx = CSng(var_1C)
  loc_00D31335: var_eax = Unknown_VTable_Call[ecx+0000039Ch]
  loc_00D31350: var_18 = Me.MousePointer
  loc_00D3138E: ecx = CSng(var_1C)
  loc_00D313A1: var_eax = Unknown_VTable_Call[eax+00000398h]
  loc_00D313BC: var_18 = Me.MousePointer
  loc_00D313FA: ecx = CSng(var_1C)
  loc_00D3140D: var_eax = Unknown_VTable_Call[ecx+00000394h]
  loc_00D31428: var_18 = Me.MousePointer
  loc_00D31466: ecx = CSng(var_1C)
  loc_00D31479: var_eax = Unknown_VTable_Call[eax+00000390h]
  loc_00D31494: var_18 = Me.MousePointer
  loc_00D314D2: ecx = CSng(var_1C)
  loc_00D314E5: var_eax = Unknown_VTable_Call[ecx+000003D4h]
  loc_00D31500: var_18 = Me.MousePointer
  loc_00D3153E: ecx = CSng(var_1C)
  loc_00D31551: var_eax = Unknown_VTable_Call[eax+000003D8h]
  loc_00D3156C: var_18 = Me.MousePointer
  loc_00D31591: var_18 = CSng(var_1C)
  loc_00D315AA: var_eax = Unknown_VTable_Call[ecx+00000410h]
  loc_00D315C5: var_18 = Me.MousePointer
  loc_00D315EA: var_18 = CSng(var_1C)
  loc_00D31620: ecx = Me - %x1 = Me.FontSize
  loc_00D31629: var_eax = Call Form2.Preparing
  loc_00D31648: var_eax = Call Form2.Train
  loc_00D31688: If (esi+00000374h = &HD2A93C) = 0 Then
  loc_00D31691:   var_eax = Unknown_VTable_Call[ecx+00000488h]
  loc_00D316AA:   Me.Enabled = True
  loc_00D316D3:   var_eax = Unknown_VTable_Call[eax+0000033Ch]
  loc_00D316EF:   Me.Left = var_42C80000
  loc_00D3172A:   var_44 = "NO"
  loc_00D31731:   If (%x1 = Me.Name = "IT") = 0 Then
  loc_00D31733:     var_44 = "YES"
  loc_00D3173A:   End If
  loc_00D31750:   ecx = "YES"
  loc_00D31763:   var_44 = "YES"
  loc_00D3176A:   If ("COMP" = Me.ForeColor = "COMP") Then
  loc_00D3176C:     var_44 = "NO"
  loc_00D31773:   End If
  loc_00D31783:   ecx = "NO"
  loc_00D3178E:   var_88 = Me.GetPalette 'Ignore this
  loc_00D317AE:   If (var_88 = "DIS") Then
  loc_00D317BD:     var_98 = Unknown_VTable_Call[ecx+00000488h] = Me.hWnd
  loc_00D317DD:     If (var_98 = "XTay") Then
  loc_00D317EC:       var_A8 = Me = Me.Name
  loc_00D3180F:       If (var_A8 = "IT") Then
  loc_00D31814:         var_68 = Me = Me.ForeColor
  loc_00D3182B:         If (var_68 = "COMP") = 0 Then
  loc_00D31830:           var_eax = Call Form2.Progr2
  loc_00D31838:           If Call Form2.Progr2 >= 0 Then GoTo loc_00D31BED
  loc_00D31843:           GoTo loc_00D31BE0
  loc_00D31848:         End If
  loc_00D3184B:         var_eax = Call Form2.Progr1
  loc_00D31853:         If Call Form2.Progr1 >= 0 Then GoTo loc_00D31BED
  loc_00D3185E:         GoTo loc_00D31BE0
  loc_00D31863:       End If
  loc_00D31866:       var_6C = esi
  loc_00D3187D:       If (var_6C = "COMP") = 0 Then
  loc_00D31882:         var_eax = Call Form2.Progr4
  loc_00D3188A:         If Call Form2.Progr4 >= 0 Then GoTo loc_00D31BED
  loc_00D31895:         GoTo loc_00D31BE0
  loc_00D3189A:       End If
  loc_00D3189D:       var_eax = Call Form2.Progr3
  loc_00D318A5:       If Call Form2.Progr3 >= 0 Then GoTo loc_00D31BED
  loc_00D318B0:       GoTo loc_00D31BE0
  loc_00D318B5:     End If
  loc_00D318D3:     If (var_98 = "TayX") = 0 Then GoTo loc_00D31BED
  loc_00D318E2:     var_B8 = 1828 = Me.Name
  loc_00D31905:     If (var_B8 = "IT") Then
  loc_00D3190A:       var_70 = 1820 = Me.ForeColor
  loc_00D31921:       If (var_70 = "COMP") = 0 Then
  loc_00D31926:         var_eax = Call Form2.Progr6
  loc_00D3192E:         If Call Form2.Progr6 >= 0 Then GoTo loc_00D31BED
  loc_00D31939:         GoTo loc_00D31BE0
  loc_00D3193E:       End If
  loc_00D31941:       var_eax = Call Form2.Progr5
  loc_00D31949:       If Call Form2.Progr5 >= 0 Then GoTo loc_00D31BED
  loc_00D31954:       GoTo loc_00D31BE0
  loc_00D31959:     End If
  loc_00D3195C:     var_74 = var_70
  loc_00D31973:     If (var_74 = "COMP") = 0 Then
  loc_00D31978:       var_eax = Call Form2.Progr8
  loc_00D31980:       If Call Form2.Progr8 >= 0 Then GoTo loc_00D31BED
  loc_00D3198B:       GoTo loc_00D31BE0
  loc_00D31990:     End If
  loc_00D31993:     var_eax = Call Form2.Progr7
  loc_00D3199B:     If Call Form2.Progr7 >= 0 Then GoTo loc_00D31BED
  loc_00D319A6:     GoTo loc_00D31BE0
  loc_00D319AB:   End If
  loc_00D319C9:   If (var_88 = "MIX") = 0 Then GoTo loc_00D31BED
  loc_00D319D8:   var_C8 = 1844 = Me.Name
  loc_00D319F8:   If (var_C8 = "IT") Then
  loc_00D31A04:     var_78 = 1836 = Me.ForeColor
  loc_00D31A1E:     If (var_78 = "COMP") = 0 Then
  loc_00D31A2A:       var_D8 = Unknown_VTable_Call[ecx+00000394h] = Me.hWnd
  loc_00D31A4A:       If (var_D8 = "XTay") Then
  loc_00D31A4F:         var_eax = Call Form2.Progr11
  loc_00D31A57:         If Call Form2.Progr11 >= 0 Then GoTo loc_00D31BED
  loc_00D31A62:         GoTo loc_00D31BE0
  loc_00D31A67:       End If
  loc_00D31A85:       If (var_D8 = "TayX") = 0 Then GoTo loc_00D31BED
  loc_00D31A8E:       var_eax = Call Form2.Progr12
  loc_00D31A96:       If Call Form2.Progr12 >= 0 Then GoTo loc_00D31BED
  loc_00D31AA1:       GoTo loc_00D31BE0
  loc_00D31AA6:     End If
  loc_00D31AAC:     var_E8 = "TayX"
  loc_00D31ACC:     If (var_E8 = "XTay") Then
  loc_00D31AD1:       var_eax = Call Form2.Progr10
  loc_00D31AD9:       If Call Form2.Progr10 >= 0 Then GoTo loc_00D31BED
  loc_00D31AE4:       GoTo loc_00D31BE0
  loc_00D31AE9:     End If
  loc_00D31B07:     If (var_E8 = "TayX") = 0 Then GoTo loc_00D31BED
  loc_00D31B10:     var_eax = Call Form2.Progr9
  loc_00D31B18:     If Call Form2.Progr9 >= 0 Then GoTo loc_00D31BED
  loc_00D31B23:     GoTo loc_00D31BE0
  loc_00D31B28:   End If
  loc_00D31B47:   If (var_C8 = "AD") = 0 Then
  loc_00D31B63:     If (var_C8 = "PT") = 0 Then GoTo loc_00D31BED
  loc_00D31B69:   End If
  loc_00D31B83:   var_54 = ("COM" = Me.ForeColor = "COM")
  loc_00D31B9B:   var_44 = "XTay"
  loc_00D31BB0:   var_ret_3 = ("COM" = Me.ForeColor = "COM") And (%x1 = Me.hWnd = "XTay")
  loc_00D31BCC:   If CBool(var_ret_3) Then
  loc_00D31BD1:     var_eax = Call Form2.Progr13
  loc_00D31BD9:     If Call Form2.Progr13 >= 0 Then GoTo loc_00D31BED
  loc_00D31BE0:     'Referenced from: 00D31843
  loc_00D31BE7:     Call Form2.Progr13 = CheckObj(Me, var_00D2A2D4, 1864)
  loc_00D31BED:   End If
  loc_00D31BED: End If
  loc_00D31BED: 
  loc_00D31BFA: GoTo loc_00D31C22
  loc_00D31C21: Exit Sub
  loc_00D31C22: 'Referenced from: 00D31BFA
End Sub