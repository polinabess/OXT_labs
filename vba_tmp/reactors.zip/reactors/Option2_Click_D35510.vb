Private Sub Option2_Click() 'D35510
  loc_00D3556C: ecx = "MIX"
  loc_00D35575: var_eax = Call Form2.Variant_process
  loc_00D35594: var_eax = Unknown_VTable_Call[eax+00000488h]
  loc_00D355AB: Me.Enabled = edi
  loc_00D355DA: GoTo loc_00D355E6
  loc_00D355E5: Exit Sub
  loc_00D355E6: 'Referenced from: 00D355DA
End Sub