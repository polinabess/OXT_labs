Private Sub Command6_Click() 'D31DD0
  loc_00D31E18: var_eax = Unknown_VTable_Call[edx+0000033Ch]
  loc_00D31E33: Me.Left = var_467A0000
  loc_00D31E5D: GoTo loc_00D31E69
  loc_00D31E68: Exit Sub
  loc_00D31E69: 'Referenced from: 00D31E5D
End Sub