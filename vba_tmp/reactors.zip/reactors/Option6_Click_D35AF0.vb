Private Sub Option6_Click() 'D35AF0
  loc_00D35B4C: ecx = "TayX"
  loc_00D35B55: var_eax = Unknown_VTable_Call[edx+00000440h]
  loc_00D35B72: Me.Caption = "               Xк"
  loc_00D35B96: var_eax = Unknown_VTable_Call[edx+00000438h]
  loc_00D35BAA: Me.Enabled = False
  loc_00D35BD4: var_eax = Unknown_VTable_Call[edx+00000434h]
  loc_00D35BE8: Me.Enabled = True
  loc_00D35C14: var_eax = Unknown_VTable_Call[edx+00000488h]
  loc_00D35C28: Me.Enabled = False
  loc_00D35C57: GoTo loc_00D35C63
  loc_00D35C62: Exit Sub
  loc_00D35C63: 'Referenced from: 00D35C57
End Sub