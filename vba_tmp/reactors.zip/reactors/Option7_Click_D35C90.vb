Private Sub Option7_Click() 'D35C90
  loc_00D35CDF: ecx = "SIRR"
  loc_00D35CE8: var_eax = Call Form2.Variant_process
  loc_00D35D07: var_eax = Unknown_VTable_Call[eax+0000038Ch]
  loc_00D35D21: Me.Left = 0
  loc_00D35D47: var_eax = Unknown_VTable_Call[eax+00000424h]
  loc_00D35D5F: Me.Caption = "  Tад"
  loc_00D35D82: var_eax = Unknown_VTable_Call[edx+00000408h]
  loc_00D35D9A: Me.Caption = " T*          K"
  loc_00D35DBD: var_eax = Unknown_VTable_Call[eax+00000404h]
  loc_00D35DD5: Me.Caption = "  E"
  loc_00D35DF8: var_eax = Unknown_VTable_Call[edx+00000418h]
  loc_00D35E0D: Me.Enabled = False
  loc_00D35E36: var_eax = Unknown_VTable_Call[eax+000003C4h]
  loc_00D35E4B: Me.Enabled = False
  loc_00D35E74: var_eax = Unknown_VTable_Call[edx+000003C0h]
  loc_00D35E89: Me.Enabled = False
  loc_00D35EB2: var_eax = Unknown_VTable_Call[eax+000003B8h]
  loc_00D35EC7: Me.Enabled = False
  loc_00D35EF0: var_eax = Unknown_VTable_Call[edx+000003B4h]
  loc_00D35F05: Me.Enabled = False
  loc_00D35F2E: var_eax = Unknown_VTable_Call[eax+000003DCh]
  loc_00D35F43: Me.WindowState = CInt(-1)
  loc_00D35F6C: var_eax = Unknown_VTable_Call[edx+000003B0h]
  loc_00D35F81: Me.Enabled = True
  loc_00D35FAA: var_eax = Unknown_VTable_Call[eax+000003ACh]
  loc_00D35FBF: Me.Enabled = True
  loc_00D35FE8: var_eax = Unknown_VTable_Call[edx+00000488h]
  loc_00D35FFC: Me.Enabled = False
  loc_00D3602C: GoTo loc_00D36038
  loc_00D36037: Exit Sub
  loc_00D36038: 'Referenced from: 00D3602C
End Sub