Private Sub Command5_Click() 'D31D10
  loc_00D31D58: var_eax = Unknown_VTable_Call[edx+0000033Ch]
  loc_00D31D6F: Me.Left = edi
  loc_00D31D99: GoTo loc_00D31DA5
  loc_00D31DA4: Exit Sub
  loc_00D31DA5: 'Referenced from: 00D31D99
End Sub