Private Sub Option8_Click() 'D36060
  loc_00D360AF: ecx = "SREV"
  loc_00D360B8: var_eax = Call Form2.Variant_process
  loc_00D360D7: var_eax = Unknown_VTable_Call[eax+0000038Ch]
  loc_00D360F4: Me.Left = var_45BB8000
  loc_00D3611A: var_eax = Unknown_VTable_Call[eax+00000424h]
  loc_00D36132: Me.Caption = "  Tад"
  loc_00D36155: var_eax = Unknown_VTable_Call[edx+00000408h]
  loc_00D3616D: Me.Caption = " T*          K"
  loc_00D36190: var_eax = Unknown_VTable_Call[eax+00000404h]
  loc_00D361A8: Me.Caption = "  E"
  loc_00D361CB: var_eax = Unknown_VTable_Call[edx+00000418h]
  loc_00D361E0: Me.Enabled = False
  loc_00D36209: var_eax = Unknown_VTable_Call[eax+000003C4h]
  loc_00D3621E: Me.Enabled = False
  loc_00D36247: var_eax = Unknown_VTable_Call[edx+000003C0h]
  loc_00D3625C: Me.Enabled = False
  loc_00D36285: var_eax = Unknown_VTable_Call[eax+000003B8h]
  loc_00D3629A: Me.Enabled = False
  loc_00D362C3: var_eax = Unknown_VTable_Call[edx+000003B4h]
  loc_00D362D8: Me.Enabled = False
  loc_00D36301: var_eax = Unknown_VTable_Call[eax+000003DCh]
  loc_00D36316: Me.WindowState = CInt(-1)
  loc_00D3633F: var_eax = Unknown_VTable_Call[edx+000003B0h]
  loc_00D36354: Me.Enabled = True
  loc_00D3637D: var_eax = Unknown_VTable_Call[eax+000003ACh]
  loc_00D36392: Me.Enabled = True
  loc_00D363BB: var_eax = Unknown_VTable_Call[edx+00000488h]
  loc_00D363CF: Me.Enabled = False
  loc_00D363FF: GoTo loc_00D3640B
  loc_00D3640A: Exit Sub
  loc_00D3640B: 'Referenced from: 00D363FF
End Sub