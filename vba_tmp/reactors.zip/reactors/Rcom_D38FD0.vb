Public Sub Rcom(Rs, Ks, ns, Zs) 'D38FD0
  loc_00D39022: call __vbaVarVargNofree(edi, __vbaVarVargNofree, ebx)
  loc_00D3902B: call __vbaVarVargNofree(__vbaVarVargNofree(edi, __vbaVarVargNofree, ebx))
  loc_00D39034: call __vbaVarVargNofree(__vbaVarVargNofree(__vbaVarVargNofree(edi, __vbaVarVargNofree, ebx)))
  loc_00D39046: var_ret_2 =  *  ^ __vbaVarVargNofree(__vbaVarVargNofree(__vbaVarVargNofree(edi, __vbaVarVargNofree, ebx)))
  loc_00D39051: call __vbaVargVarMove
  loc_00D3905C: GoTo loc_00D39072
  loc_00D39071: Exit Sub
  loc_00D39072: 'Referenced from: 00D3905C
End Sub