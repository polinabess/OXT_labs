Private Sub Option10_Click() 'D34030
  loc_00D3408C: ecx = "AD"
  loc_00D34095: var_eax = Call Form2.Variant_process
  loc_00D340B4: var_eax = Unknown_VTable_Call[eax+0000040Ch]
  loc_00D340CE: Me.WindowState = CInt(-1)
  loc_00D340F8: var_eax = Unknown_VTable_Call[eax+00000420h]
  loc_00D3410C: Me.WindowState = 0
  loc_00D34136: var_eax = Unknown_VTable_Call[eax+00000414h]
  loc_00D3414A: Me.Enabled = False
  loc_00D34174: var_eax = Unknown_VTable_Call[eax+00000410h]
  loc_00D34188: Me.Enabled = False
  loc_00D341B4: var_eax = Unknown_VTable_Call[eax+00000488h]
  loc_00D341C8: Me.Enabled = False
  loc_00D341F7: GoTo loc_00D34203
  loc_00D34202: Exit Sub
  loc_00D34203: 'Referenced from: 00D341F7
End Sub