Private Sub Option3_Click() 'D35610
  loc_00D3566C: ecx = "IT"
  loc_00D35675: var_eax = Call Form2.Variant_process
  loc_00D35694: var_eax = Unknown_VTable_Call[eax+0000040Ch]
  loc_00D356AE: Me.WindowState = 0
  loc_00D356DA: var_eax = Unknown_VTable_Call[eax+00000488h]
  loc_00D356EE: Me.Enabled = False
  loc_00D3571D: GoTo loc_00D35729
  loc_00D35728: Exit Sub
  loc_00D35729: 'Referenced from: 00D3571D
End Sub