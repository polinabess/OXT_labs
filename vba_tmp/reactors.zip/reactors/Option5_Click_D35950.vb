Private Sub Option5_Click() 'D35950
  loc_00D359AC: ecx = "XTay"
  loc_00D359B5: var_eax = Unknown_VTable_Call[edx+00000440h]
  loc_00D359D2: Me.Caption = "Tay"
  loc_00D359F6: var_eax = Unknown_VTable_Call[edx+00000434h]
  loc_00D35A0A: Me.Enabled = False
  loc_00D35A34: var_eax = Unknown_VTable_Call[edx+00000438h]
  loc_00D35A48: Me.Enabled = True
  loc_00D35A74: var_eax = Unknown_VTable_Call[edx+00000488h]
  loc_00D35A88: Me.Enabled = False
  loc_00D35AB7: GoTo loc_00D35AC3
  loc_00D35AC2: Exit Sub
  loc_00D35AC3: 'Referenced from: 00D35AB7
End Sub