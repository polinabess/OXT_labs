Private Sub Command1_Click() 'D308E0
  loc_00D30947: var_eax = Unknown_VTable_Call[ecx+00000074h]
  loc_00D30981: Option11.Value = True
  loc_00D309B1: GoTo loc_00D309BD
  loc_00D309BC: Exit Sub
  loc_00D309BD: 'Referenced from: 00D309B1
End Sub