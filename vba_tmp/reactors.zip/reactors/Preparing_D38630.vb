Public Sub Preparing() 'D38630
  Dim var_ret_8 As Me
  loc_00D386A7: ecx = esi+000001CCh + Me.ClipControls = Me
  loc_00D386F5: ecx = Me.Visible = %x1b - esi+00000474h - Me.Visible = %x1b
  loc_00D38717: ecx = esi+00000484h * esi+000001ECh
  loc_00D3871F: fcomp real4 ptr [004012E8h]
  loc_00D3872A: If Err.Number Then
  loc_00D3874D:   GoTo loc_00D387C2
  loc_00D3874F: End If
  loc_00D38778: var_ret_5 = 1 / Me.Visible = %x1b ^ Me.Visible = %x1b
  loc_00D3877F: var_ret_5 = CSng()
  loc_00D387A3: var_7C = esi+000001FCh
  loc_00D387BE: var_ret_7 = esi+000001FC / Me.Visible = %x1b / esi+000001ECh
  loc_00D387C2: 'Referenced from: 00D3874D
  loc_00D387C8: ecx = var_ret_7
  loc_00D387E2: var_7C = esi+000004B4h
  loc_00D387EF: var_ret_8 = esi+000001CCh ^ esi+000001CCh
  loc_00D38835: var_ret_D =  * Me.ClipControls = %x1b ^ Me.ClipControls = %x1b * esi+000001ECh ^ esi+00000484h * esi+000004B4
  loc_00D38838: var_ret_D = CSng()
  loc_00D3884A: GoTo loc_00D38870
  loc_00D3886F: Exit Sub
  loc_00D38870: 'Referenced from: 00D3884A
End Sub