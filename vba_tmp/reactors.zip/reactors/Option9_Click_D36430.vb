Private Sub Option9_Click() 'D36430
  loc_00D3647F: ecx = "COMP"
  loc_00D36488: var_eax = Call Form2.Variant_process
  loc_00D364A7: var_eax = Unknown_VTable_Call[eax+0000038Ch]
  loc_00D364C1: Me.Left = 0
  loc_00D364E7: var_eax = Unknown_VTable_Call[eax+00000424h]
  loc_00D364FF: Me.Caption = "Tад1      Tад2"
  loc_00D36522: var_eax = Unknown_VTable_Call[edx+00000408h]
  loc_00D3653A: Me.Caption = " T*        K1  K2  K3"
  loc_00D3655D: var_eax = Unknown_VTable_Call[eax+00000404h]
  loc_00D36575: Me.Caption = "E1 E2 E3"
  loc_00D36598: var_eax = Unknown_VTable_Call[edx+00000418h]
  loc_00D365AD: Me.Enabled = True
  loc_00D365D6: var_eax = Unknown_VTable_Call[eax+000003C4h]
  loc_00D365EB: Me.Enabled = True
  loc_00D36614: var_eax = Unknown_VTable_Call[edx+000003C0h]
  loc_00D36629: Me.Enabled = True
  loc_00D36652: var_eax = Unknown_VTable_Call[eax+000003B8h]
  loc_00D36667: Me.Enabled = True
  loc_00D36690: var_eax = Unknown_VTable_Call[edx+000003B4h]
  loc_00D366A5: Me.Enabled = True
  loc_00D366CE: var_eax = Unknown_VTable_Call[eax+000003DCh]
  loc_00D366E3: Me.WindowState = 0
  loc_00D3670C: var_eax = Unknown_VTable_Call[edx+000003B0h]
  loc_00D36721: Me.Enabled = False
  loc_00D3674A: var_eax = Unknown_VTable_Call[eax+000003ACh]
  loc_00D3675F: Me.Enabled = False
  loc_00D36788: var_eax = Unknown_VTable_Call[edx+00000488h]
  loc_00D3679C: Me.Enabled = False
  loc_00D367CC: GoTo loc_00D367D8
  loc_00D367D7: Exit Sub
  loc_00D367D8: 'Referenced from: 00D367CC
End Sub