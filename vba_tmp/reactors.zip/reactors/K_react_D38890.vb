Public Sub K_react(Ks, Tc, Tz, Kz, Ej) 'D38890
  loc_00D3896C: call __vbaVarVargNofree(__vbaVarVargNofree, ebx)
  loc_00D38994: var_ret_2 = __vbaVarVargNofree(__vbaVarVargNofree, ebx) * 1000 / Me.SaveProp 'Ignore this
  loc_00D389A7: call __vbaVarVargNofree(var_C4, var_ret_2)
  loc_00D389AE: var_ret_3 =  / __vbaVarVargNofree(var_C4, var_ret_2)
  loc_00D389C1: call __vbaVarVargNofree(var_E4, var_ret_3)
  loc_00D389DA: var_ret_6 =  *  -  / __vbaVarVargNofree(var_E4, var_ret_3)
  loc_00D38A08: call __vbaVarVargNofree
  loc_00D38A19: var_ret_7 = __vbaVarVargNofree * 0#
  loc_00D38A20: call __vbaVargVarMove
  loc_00D38A2C: GoTo loc_00D38A59
  loc_00D38A58: Exit Sub
  loc_00D38A59: 'Referenced from: 00D38A2C
End Sub