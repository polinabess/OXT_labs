Private Sub Option15_Click() 'D35170
  loc_00D351BA: var_eax = Unknown_VTable_Call[edx+0000031Ch]
  loc_00D351D4: Me.Width = 0
  loc_00D35200: var_eax = Unknown_VTable_Call[edx+00000320h]
  loc_00D35215: Me.Width = 0
  loc_00D3523E: var_eax = Unknown_VTable_Call[eax+00000324h]
  loc_00D35253: Me.Width = 0
  loc_00D3527C: var_eax = Unknown_VTable_Call[edx+00000328h]
  loc_00D35291: Me.Width = 0
  loc_00D352BA: var_eax = Unknown_VTable_Call[eax+0000032Ch]
  loc_00D352CF: Me.Width = 0
  loc_00D352F8: var_eax = Unknown_VTable_Call[edx+00000330h]
  loc_00D3530D: Me.Width = 0
  loc_00D35336: var_eax = Unknown_VTable_Call[eax+00000334h]
  loc_00D3534B: Me.Width = NAN
  loc_00D35389: VScroll1.Value = 0
  loc_00D353C6: VScroll1.Max = 0
  loc_00D353F6: var_eax = Call Form2.VScroll1_Change
  loc_00D3541F: GoTo loc_00D3542B
  loc_00D3542A: Exit Sub
  loc_00D3542B: 'Referenced from: 00D3541F
End Sub